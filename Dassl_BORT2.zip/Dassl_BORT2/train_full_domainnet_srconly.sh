data_conf=configs/datasets/da/domainnet.yaml
conf=configs/trainers/da/source_only/domainnet.yaml
run='yes'
for((i=0;i>=0;i++));do
#if [ $run == "yes" ];then
opt='MODEL.BACKBONE.NAME resnet101_adapkernel'
CUDA_VISIBLE_DEVICES=2 python tools/train.py  --root ~/data --trainer SourceOnly \
	 --source-domains sketch painting clipart quickdraw real --target-domains infograph \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/source_only_domainnet/infograph  \
   	 --resume output/source_only_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/source_only_domainnet/srconly_infograph_${i}.log &
#if [ $run == "yes" ];then
CUDA_VISIBLE_DEVICES=3 python tools/train.py  --root ~/data --trainer SourceOnly \
	 --source-domains sketch infograph clipart quickdraw painting --target-domains real \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/source_only_domainnet/real  \
   	 --resume output/source_only_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/source_only_domainnet/srconly_real_${i}.log & 
CUDA_VISIBLE_DEVICES=4 python tools/train.py  --root ~/data --trainer SourceOnly \
	 --source-domains painting infograph clipart quickdraw real --target-domains sketch \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/source_only_domainnet/sketch  \
   	 --resume output/source_only_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/source_only_domainnet/srconly_sketch_${i}.log &
if [ $run == "yes" ];then
CUDA_VISIBLE_DEVICES=5 python tools/train.py  --root ~/data --trainer SourceOnly \
	 --source-domains sketch infograph painting quickdraw real --target-domains clipart \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/source_only_domainnet/clipart  \
   	 --resume output/source_only_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/source_only_domainnet/srconly_clipart_${i}.log &
#if [ $run == "yes" ];then
#fi
CUDA_VISIBLE_DEVICES=6 python tools/train.py  --root ~/data --trainer SourceOnly \
	 --source-domains sketch infograph clipart quickdraw real --target-domains painting \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/source_only_domainnet/painting  \
   	 --resume output/source_only_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/source_only_domainnet/srconly_painting_${i}.log &
CUDA_VISIBLE_DEVICES=7 python tools/train.py  --root ~/data --trainer SourceOnly \
	 --source-domains sketch infograph painting clipart real --target-domains quickdraw \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/source_only_domainnet/quickdraw  \
   	 --resume output/source_only_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/source_only_domainnet/srconly_quickdraw_${i}.log &
fi
done
