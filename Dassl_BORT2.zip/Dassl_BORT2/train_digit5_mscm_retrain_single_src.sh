conf=configs/trainers/da/digit5_single_src.yaml
#conf=configs/trainers/da/ca_loss/digit5_staged_lr.yaml
data_conf=configs/datasets/da/digit5.yaml 
trainer=FixMatchMSCMRetrain
#opt='MODEL.BACKBONE.NAME cnn_digit5_m3sda_adapt_kernel'
a=1
#GPU=6
for((i=30;i<=32;i++));do
if (( $i == 32 ));then
GPU=6
else
GPU=3
fi
if (( $a == 1 ));then
#GPU=3
opt='MODEL.BACKBONE.NAME cnn_digitsingle TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.CUTMIX.PROB 0. TRAINER.RETRAIN.EPOCH 30'
CUDA_VISIBLE_DEVICES=$GPU python tools/train.py --root ../../data --trainer $trainer \
	--source-domains  usps --target-domains mnist  \
	--dataset-config-file ${data_conf} --config-file ${conf}  \
	--output-dir output/mscm_retrain_digitsingle/mnist --resume output/adaptkernel_digit5/usps/nomodel  \
	$opt 2>&1|tee output/mscm_retrain_digitsingle/fm_usps2mnist_${i}.log &
((GPU=GPU+1))
fi
if (( $a == 1 ));then
#GPU=1
CUDA_VISIBLE_DEVICES=$GPU python tools/train.py --root ../../data --trainer $trainer \
	--source-domains mnist --target-domains usps  \
	--dataset-config-file ${data_conf} --config-file ${conf}  \
	--output-dir output/mscm_retrain_digitsingle/usps --resume output/adaptkernel_digit5/usps/nomodel  \
	$opt 2>&1|tee output/mscm_retrain_digitsingle/fm_mnist2usps_${i}.log &
((GPU=GPU+1))
fi
if (( $GPU > 7 )); then
GPU=7
fi
opt='MODEL.BACKBONE.NAME cnn_digit5_m3sda TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.CUTMIX.PROB 0. TRAINER.RETRAIN.EPOCH 30'
#GPU=4
CUDA_VISIBLE_DEVICES=$GPU python tools/train.py --root ../../data --trainer $trainer \
	--source-domains svhn --target-domains mnist  \
	--dataset-config-file ${data_conf} --config-file ${conf}  \
	--output-dir output/mscm_retrain_digitsingle/mnist --resume output/adaptkernel_digit5/usps/nomodel  \
	$opt 2>&1|tee output/mscm_retrain_digitsingle/fm_svhn2mnist_${i}.log & 
#fi
done
