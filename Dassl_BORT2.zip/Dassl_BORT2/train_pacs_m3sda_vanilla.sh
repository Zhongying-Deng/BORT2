retrain=1
if (( $retrain == 0 )); then
trainer=M3SDA
else
trainer=FixMatchBaselinesRetrain
fi
conf=configs/trainers/da/pacs_staged_lr.yaml
#conf=configs/trainers/da/source_only/pacs_staged_lr.yaml
data_conf=configs/datasets/da/pacs.yaml
#opt='MODEL.BACKBONE.NAME resnet18 OPTIM.MAX_EPOCH 20'
opt='MODEL.BACKBONE.NAME resnet18 OPTIM.MAX_EPOCH 20 TRAINER.M3SDA.LMDA 0.1'
for((i=9;i<=9;i++));do
#if (( $retrain == 0 )); then
trainer=M3SDA
opt='MODEL.BACKBONE.NAME resnet18 OPTIM.MAX_EPOCH 20 TRAINER.M3SDA.LMDA 0.1'
	GPU=0
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon sketch --target-domains photo  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines/photo_m3sda --resume output/src_only_pacs/sketch/nomodel $opt  2>&1|tee output/pacs_baselines/m3sda_photo_${i}.log &
	GPU=1
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon photo --target-domains sketch  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines/sketch_m3sda --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines/m3sda_sketch_${i}.log &
	#sleep 7m
	GPU=2
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting sketch photo --target-domains cartoon  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines/cartoon_m3sda --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines/m3sda_cartoon_${i}.log &
	GPU=3
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains sketch cartoon photo --target-domains art_painting  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines/art_m3sda --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines/m3sda_art_${i}.log
	sleep 15m
#else
trainer=FixMatchBaselinesRetrain
        GPU=4
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/photo_m3sda/F/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18' 
        #opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 70 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.NAME resnet18_drt'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon sketch --target-domains photo  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/photo_m3sda --resume output/src_only_pacs/sketch/nomodel $opt  2>&1|tee output/pacs_baselines_retrain/m3sda_photo_${i}.log &
	GPU=5
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/sketch_m3sda/F/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon photo --target-domains sketch  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/sketch_m3sda --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/m3sda_sketch_${i}.log &
	#sleep 7m
	GPU=6
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/cartoon_m3sda/F/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting sketch photo --target-domains cartoon  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/cartoon_m3sda --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/m3sda_cartoon_${i}.log &
	GPU=7
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/art_m3sda/F/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains sketch cartoon photo --target-domains art_painting  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/art_m3sda --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/m3sda_art_${i}.log
	sleep 15m
#fi
done
