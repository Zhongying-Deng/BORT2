#sleep 8m
a=0
#if (( $a == 1 ));
#then
trainer=FixMatchMSCMDistNetMetaLearnRetrain
#FixMatchBaselineDistNetMetaLearnRetrainCE
#FixMatchMSCMRetrain
#SoftThreshold
#opt='MODEL.BACKBONE.NAME resnet18_ms TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 150 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 50'
#opt=' '
outpath=pacs_fm_dida_dist_net_meta_learn_retrain
for((i=6;i<=7;i++));
do
if (( $i == 3 ));then
GPU=0
else
GPU=0
fi
if (( $a == 1 ));then
#opt='MODEL.BACKBONE.NAME resnet18_adapkernel TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 MODEL.INIT_WEIGHTS output/adaptkernel_pacs/photo/model/model.pth.tar-100'
opt='MODEL.BACKBONE.NAME resnet18_adapkernel TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 100 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 50 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 MODEL.INIT_WEIGHTS output/pacs_fm_dida_dist_net_meta_learn_retrain/photo/model_tar/model.pth.tar-50'
#DATASET.NAME PACSDATargetVal'
CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer ${trainer} \
 --source-domains art_painting cartoon sketch --target-domains photo \
 --dataset-config-file configs/datasets/da/pacs.yaml \
 --config-file configs/trainers/da/pacs_staged_lr.yaml \
 --output-dir output/${outpath}/photo \
 --resume output/adaptkernel_pacs/sketch/nomodel \
 $opt  2>&1|tee output/${outpath}/fm_photo_${i}.log &
((GPU=GPU+1))
fi
#if (( $a == 1 ));then
#GPU=4
#opt='MODEL.BACKBONE.NAME resnet18_adapkernel TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 MODEL.INIT_WEIGHTS output/adaptkernel_pacs/sketch/model/model.pth.tar-40'
opt='MODEL.BACKBONE.NAME resnet18_adapkernel TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 100 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 50 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 MODEL.INIT_WEIGHTS output/adaptkernel_pacs/sketch/model/model-best.pth.tar'
#DATASET.NAME PACSDATargetVal'
CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer ${trainer} \
 --source-domains art_painting cartoon photo --target-domains sketch \
 --dataset-config-file configs/datasets/da/pacs.yaml \
 --config-file configs/trainers/da/pacs_staged_lr.yaml \
 --output-dir output/${outpath}/sketch \
 --resume output/adaptkernel_pacs/sketch/nomodel \
 $opt 2>&1|tee output/${outpath}/fm_sketch_${i}.log &
#sleep 15m
if (( $a == 1 ));then
((GPU=GPU+1))
GPU=4
#opt='MODEL.BACKBONE.NAME resnet18_adapkernel TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 MODEL.INIT_WEIGHTS output/adaptkernel_pacs/art_painting/model/model.pth.tar-100'
opt='MODEL.BACKBONE.NAME resnet18_adapkernel TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 100 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 50 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 MODEL.INIT_WEIGHTS output/pacs_fm_dida_dist_net_meta_learn_retrain/art_painting/model_tar/model.pth.tar-50'
#  DATASET.NAME PACSDATargetVal'
CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer ${trainer} \
 --source-domains photo cartoon sketch --target-domains art_painting \
 --dataset-config-file configs/datasets/da/pacs.yaml \
 --config-file configs/trainers/da/pacs_staged_lr.yaml \
 --output-dir output/${outpath}/art_painting \
 --resume output/adaptkernel_pacs/sketch/nomodel \
 $opt 2>&1|tee output/${outpath}/fm_art_${i}.log &
#fi
((GPU=GPU+1))
#GPU=5
#opt='MODEL.BACKBONE.NAME resnet18_adapkernel TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 MODEL.INIT_WEIGHTS output/adaptkernel_pacs/cartoon/model/model.pth.tar-80'
opt='MODEL.BACKBONE.NAME resnet18_adapkernel TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 100 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 50 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 MODEL.INIT_WEIGHTS output/pacs_fm_dida_dist_net_meta_learn_retrain/cartoon/model_tar/model.pth.tar-50'
#  DATASET.NAME PACSDATargetVal'
CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer ${trainer} \
 --source-domains art_painting photo sketch --target-domains cartoon \
 --dataset-config-file configs/datasets/da/pacs.yaml \
 --config-file configs/trainers/da/pacs_staged_lr.yaml \
 --output-dir output/${outpath}/cartoon \
 --resume output/adaptkernel_pacs/sketch/nomodel \
 $opt 2>&1|tee output/${outpath}/fm_cartoon_${i}.log &
#sleep 15m
fi
done
