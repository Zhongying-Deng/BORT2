metatrain=1
if (( $metatrain == 1 )); then
trainer=FixMatchBaselinesDistNetMetaLearnRetrain
else
trainer=FixMatchBaselinesDistNetRetrain
fi
conf=configs/trainers/da/pacs_staged_lr.yaml
#conf=configs/trainers/da/source_only/pacs_staged_lr.yaml
data_conf=configs/datasets/da/pacs.yaml
#opt='MODEL.BACKBONE.NAME resnet18 OPTIM.MAX_EPOCH 20'
opt='MODEL.BACKBONE.NAME resnet18 OPTIM.MAX_EPOCH 20 TRAINER.M3SDA.LMDA 0.1'
for((i=5;i<=5;i++));do
if (( $metatrain == 0 )); then
        GPU=4
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/photo_dann/model/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18' 
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon sketch --target-domains photo  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/photo_dann --resume output/src_only_pacs/sketch/nomodel $opt  2>&1|tee output/pacs_baselines_retrain/dann_photo_${i}.log &
	GPU=5
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/sketch_dann/model/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon photo --target-domains sketch  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/sketch_dann --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/dann_sketch_${i}.log &
	#sleep 7m
	GPU=6
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/cartoon_dann/model/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting sketch photo --target-domains cartoon  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/cartoon_dann --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/dann_cartoon_${i}.log &
	GPU=7
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/art_dann/model/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains sketch cartoon photo --target-domains art_painting  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/art_dann --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/dann_art_${i}.log & 
else
        GPU=4
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines_retrain/photo_dann/model/model.pth.tar-50 MODEL.BACKBONE.NAME resnet18 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30' 
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon sketch --target-domains photo  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/photo_dann_meta --resume output/src_only_pacs/sketch/nomodel $opt  2>&1|tee output/pacs_baselines_retrain/dann_photo_${i}.log &
	GPU=5
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines_retrain/sketch_dann/model/model.pth.tar-50 MODEL.BACKBONE.NAME resnet18 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon photo --target-domains sketch  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/sketch_dann_meta --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/dann_sketch_${i}.log &
	#sleep 7m
	GPU=6
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines_retrain/cartoon_dann/model/model.pth.tar-50 MODEL.BACKBONE.NAME resnet18 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting sketch photo --target-domains cartoon  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/cartoon_dann_meta --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/dann_cartoon_${i}.log &
	GPU=7
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines_retrain/art_dann/model/model.pth.tar-50 MODEL.BACKBONE.NAME resnet18 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains sketch cartoon photo --target-domains art_painting  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/art_dann_meta --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/dann_art_${i}.log &
fi
done
