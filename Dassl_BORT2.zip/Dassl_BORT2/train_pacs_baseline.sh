trainer=SourceOnly
conf=configs/trainers/da/source_only/pacs_staged_lr.yaml
data_conf=configs/datasets/da/pacs.yaml
opt='MODEL.BACKBONE.NAME resnet18_adapkernel'
for((i=2;i<=2;i++));do
	GPU=6
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon sketch --target-domains photo  --dataset-config-file $data_conf --config-file $conf  --output-dir output/srconly_pacs/photo --resume output/src_only_pacs/sketch/nomodel $opt  2>&1|tee output/srconly_pacs/adapt_kernel_photo_${i}.log &
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon photo --target-domains sketch  --dataset-config-file $data_conf --config-file $conf  --output-dir output/srconly_pacs/sketch --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/srconly_pacs/adapt_kernel_sketch_${i}.log &
	((GPU=GPU+1))
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting sketch photo --target-domains cartoon  --dataset-config-file $data_conf --config-file $conf  --output-dir output/srconly_pacs/cartoon --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/srconly_pacs/adapt_kernel_cartoon_${i}.log &
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains sketch cartoon photo --target-domains art_painting  --dataset-config-file $data_conf --config-file $conf  --output-dir output/srconly_pacs/art --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/srconly_pacs/adapt_kernel_art_${i}.log
	sleep 15m
done
