trainer=M3SDA
data_conf=configs/datasets/da/domainnet.yaml
conf=configs/trainers/da/domainnet_staged_lr_noaug.yaml
run='yes'
if [ $run == "yes" ];then
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/infograph_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1 DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
opt='MODEL.BACKBONE.NAME resnet101_drt TRAINER.M3SDA.LMDA 0.1'
CUDA_VISIBLE_DEVICES=0 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch painting clipart quickdraw real --target-domains infograph \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/domainnet_drt/infograph  \
   	 --resume output/domainnet_drt/clipart/nomodel \
	 ${opt} 2>&1| tee output/domainnet_drt/drt_infograph_baseline_0.log &
#if [ $run == "yes" ];then
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/real_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1 DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
CUDA_VISIBLE_DEVICES=1 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart quickdraw painting --target-domains real \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/domainnet_drt/real  \
   	 --resume output/domainnet_drt/clipart/nomodel \
	 ${opt} 2>&1| tee output/domainnet_drt/drt_real_baseline_0.log &
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/sketch_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1 DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
CUDA_VISIBLE_DEVICES=2 python tools/train.py  --root ~/data --trainer ${trainer} \
	--source-domains painting infograph clipart quickdraw real --target-domains sketch \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/domainnet_drt/sketch  \
   	 --resume output/domainnet_drt/clipart/nomodel \
	 ${opt} 2>&1| tee output/domainnet_drt/drt_sketch_baseline_0.log &
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/clipart_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1 DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
CUDA_VISIBLE_DEVICES=3 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph painting quickdraw real --target-domains clipart \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/domainnet_drt/clipart  \
   	 --resume output/domainnet_drt/clipart/nomodel \
	 ${opt} 2>&1| tee output/domainnet_drt/drt_clipart_baseline_0.log &
#if [ $run == "yes" ];then
#fi
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/painting_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1  DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
CUDA_VISIBLE_DEVICES=4 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart quickdraw real --target-domains painting \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/domainnet_drt/painting  \
   	 --resume output/domainnet_drt/clipart/nomodel \
	 ${opt} 2>&1| tee output/domainnet_drt/drt_painting_baseline_0.log &
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/quickdraw_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1 DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
CUDA_VISIBLE_DEVICES=5 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph painting clipart real --target-domains quickdraw \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/domainnet_drt/quickdraw  \
   	 --resume output/domainnet_drt/clipart/nomodel \
	 ${opt} 2>&1| tee output/domainnet_drt/drt_quickdraw_baseline_0.log &
fi
