retrain=1
if (( $retrain == 0 )); then
trainer=MCD
else
trainer=FixMatchBaselinesDistNetRetrain
fi
conf=configs/trainers/da/pacs_staged_lr.yaml
#conf=configs/trainers/da/source_only/pacs_staged_lr.yaml
data_conf=configs/datasets/da/pacs.yaml
opt='MODEL.BACKBONE.NAME resnet18 OPTIM.MAX_EPOCH 20'
#opt='MODEL.BACKBONE.NAME resnet18_drt OPTIM.MAX_EPOCH 20 TRAINER.M3SDA.LMDA 0.1'
for((i=10;i<=11;i++));do
#if (( $retrain == 0 )); then
trainer=MCD
if (( $i > 9 )); then
        opt='MODEL.BACKBONE.NAME resnet18 OPTIM.MAX_EPOCH 20 TRAINER.RETRAIN.METHOD MCD'
	GPU=4
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon sketch --target-domains photo  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines/photo_mcd2 --resume output/src_only_pacs/sketch/nomodel $opt  2>&1|tee output/pacs_baselines/mcd_photo_${i}.log &
	GPU=5
	CUDA_VISIBiLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon photo --target-domains sketch  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines/sketch_mcd2 --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines/mcd_sketch_${i}.log &
	#sleep 7m2
	GPU=6
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting sketch photo --target-domains cartoon  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines/cartoon_mcd2 --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines/mcd_cartoon_${i}.log &
	GPU=7
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains sketch cartoon photo --target-domains art_painting  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines/art_mcd2 --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines/mcd_art_${i}.log
	sleep 15m
fi
#else
trainer=FixMatchBaselinesRetrain
        GPU=0
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/photo_mcd2/F/model.pth.tar-20 TRAINER.RETRAIN.METHOD MCD'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon sketch --target-domains photo  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/photo_mcd --resume output/src_only_pacs/sketch/nomodel $opt  2>&1|tee output/pacs_baselines_retrain/mcd_photo_${i}.log &
	GPU=1
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/sketch_mcd2/F/model.pth.tar-20 TRAINER.RETRAIN.METHOD MCD'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon photo --target-domains sketch  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/sketch_mcd --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/mcd_sketch_${i}.log &
	#sleep 7m
	GPU=2
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/cartoon_mcd2/F/model.pth.tar-20 TRAINER.RETRAIN.METHOD MCD'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting sketch photo --target-domains cartoon  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/cartoon_mcd --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/mcd_cartoon_${i}.log &
	GPU=3
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/art_mcd2/F/model.pth.tar-20 TRAINER.RETRAIN.METHOD MCD'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains sketch cartoon photo --target-domains art_painting  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/art_mcd --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/mcd_art_${i}.log
	sleep 15m
#fi
done
