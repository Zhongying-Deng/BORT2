#sleep 3h
#trainer=ChannelAttenLossMSDAWithCenterLoss
trainer=ChannelAttenLossMSDAWithTarCompact
#FixMatchDomain
#trainer=FixMatchEMA
opts='TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1'
#opts='MODEL.BACKBONE.NAME resnet18_adaptkernel_ms'
#'MODEL.BACKBONE.NAME resnet18_adapkernel'
conf=configs/trainers/da/ca_loss/pacs.yaml
#configs/trainers/da/pacs_staged_lr.yaml 
folder=caloss_pacs
GPU=6
a=0
for((num=36;num<=38;num++));
do
GPU=4
CUDA_VISIBLE_DEVICES=$GPU python tools/train.py --root ../../data/ --trainer ${trainer} \
 --source-domains art_painting cartoon sketch --target-domains photo \
 --dataset-config-file configs/datasets/da/pacs_ca.yaml \
 --config-file $conf \
 --output-dir output/${folder}/photo \
 --resume output/${folder}/sketch/nomodel \
 ${opts} 2>&1|tee output/${folder}/fm_tarcomp_photo_${num}.log &
#if (( $a == 1 ));then
CUDA_VISIBLE_DEVICES=$GPU python tools/train.py --root ../../data/ --trainer ${trainer} \
 --source-domains art_painting cartoon photo --target-domains sketch \
 --dataset-config-file configs/datasets/da/pacs_ca.yaml \
 --config-file $conf \
 --output-dir output/${folder}/sketch \
 --resume output/${folder}/sketch/nomodel \
 ${opts} 2>&1|tee output/${folder}/fm_tarcomp_sketch_${num}.log 
#if (( $a == 1 ));
#then
GPU=5
CUDA_VISIBLE_DEVICES=$GPU python tools/train.py --root ../../data/ --trainer ${trainer} \
 --source-domains photo cartoon sketch --target-domains art_painting \
 --dataset-config-file configs/datasets/da/pacs_ca.yaml \
 --config-file $conf \
 --output-dir output/${folder}/art_painting \
 --resume output/${folder}/sketch/nomodel \
 ${opts} 2>&1|tee output/${folder}/fm_tarcomp_art_${num}.log &
#sleep 15m
#if (( $a == 1 ));
#then
CUDA_VISIBLE_DEVICES=$GPU python tools/train.py --root ../../data/ --trainer ${trainer} \
 --source-domains art_painting photo sketch --target-domains cartoon \
 --dataset-config-file configs/datasets/da/pacs_ca.yaml \
 --config-file $conf \
 --output-dir output/${folder}/cartoon \
 --resume output/${folder}/sketch/nomodel \
 ${opts} 2>&1|tee output/${folder}/fm_tarcomp_cartoon_${num}.log
sleep 10m
#fi
done
