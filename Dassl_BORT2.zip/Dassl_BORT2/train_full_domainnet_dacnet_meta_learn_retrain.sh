#trainer=FixMatchMSCMDistNetMetaLearnRetrain
trainer=FixMatchMSCMDistNetRetrain
data_conf=configs/datasets/da/domainnet.yaml
conf=configs/trainers/da/domainnet_staged_lr.yaml
#opt='MODEL.BACKBONE.NAME resnet101_ms'
a=0
sleep 5h
for((i=4;i<=4;i++));do
if (( $a == 0 ));then
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/caloss_domainnet/infograph/model/model.pth.tar-20 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101_ca TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/dacnet_meta_learn_retrain_domainnet/infograph/model_tar/model.pth.tar-15 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101_ca TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 15 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
CUDA_VISIBLE_DEVICES=1 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch painting clipart quickdraw real --target-domains infograph \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/dacnet_meta_learn_retrain_domainnet/infograph  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/dacnet_meta_learn_retrain_domainnet/fm_infograph_${i}.log &
fi
if (( $a == 1 ));then
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/caloss_domainnet/real/model/model.pth.tar-20 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101_ca TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
CUDA_VISIBLE_DEVICES=0 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart quickdraw painting --target-domains real \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/dacnet_meta_learn_retrain_domainnet/real  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/dacnet_meta_learn_retrain_domainnet/fm_real_${i}.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/caloss_domainnet/sketch/model/model.pth.tar-20 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101_ca TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
CUDA_VISIBLE_DEVICES=5 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains painting infograph clipart quickdraw real --target-domains sketch \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/dacnet_meta_learn_retrain_domainnet/sketch  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/dacnet_meta_learn_retrain_domainnet/fm_sketch_${i}.log &
else
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/caloss_domainnet/clipart/model/model.pth.tar-20 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101_ca TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
CUDA_VISIBLE_DEVICES=2 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph painting quickdraw real --target-domains clipart \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/dacnet_meta_learn_retrain_domainnet/clipart  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/dacnet_meta_learn_retrain_domainnet/fm_clipart_${i}.log &
#else
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/caloss_domainnet/painting/model/model.pth.tar-20 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101_ca TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
CUDA_VISIBLE_DEVICES=4 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart quickdraw real --target-domains painting \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/dacnet_meta_learn_retrain_domainnet/painting  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/dacnet_meta_learn_retrain_domainnet/fm_painting_${i}.log &
fi
if (( $a == 0 ));then
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/caloss_domainnet/quickdraw/model/model.pth.tar-20 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101_ca TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/dacnet_meta_learn_retrain_domainnet/quickdraw/model_tar/model.pth.tar-15 OPTIM.MAX_EPOCH 1 MODEL.BACKBONE.NAME resnet101_ca TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 1 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
CUDA_VISIBLE_DEVICES=3 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart real painting --target-domains quickdraw \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/dacnet_meta_learn_retrain_domainnet/quickdraw  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/dacnet_meta_learn_retrain_domainnet/fm_quickdraw_${i}.log &
fi
done
