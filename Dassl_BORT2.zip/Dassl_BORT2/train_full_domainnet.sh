data_conf=configs/datasets/da/domainnet_ca.yaml
conf=configs/trainers/da/ca_loss/domainnet_staged_lr.yaml
run='no'
#if [ $run == "yes" ];then

opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/infograph_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1 DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
CUDA_VISIBLE_DEVICES=0 python tools/train.py  --root ~/data --trainer ChannelAttenLossMSDAWithTarCompact \
	 --source-domains sketch painting clipart quickdraw real --target-domains infograph \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/infograph  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_infograph_batch8.log &
#if [ $run == "yes" ];then
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/real_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1 DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
CUDA_VISIBLE_DEVICES=4 python tools/train.py  --root ~/data --trainer ChannelAttenLossMSDAWithTarCompact \
	 --source-domains sketch infograph clipart quickdraw painting --target-domains real \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/real  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_real_batch8.log 
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/sketch_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1 DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
CUDA_VISIBLE_DEVICES=4 python tools/train.py  --root ~/data --trainer ChannelAttenLossMSDAWithTarCompact \
	 --source-domains painting infograph clipart quickdraw real --target-domains sketch \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/sketch  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_sketch_batch8.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/clipart_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1 DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
CUDA_VISIBLE_DEVICES=0 python tools/train.py  --root ~/data --trainer ChannelAttenLossMSDAWithTarCompact \
	 --source-domains sketch infograph painting quickdraw real --target-domains clipart \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/clipart  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_clipart_batch8.log
if [ $run == "yes" ];then
#fi
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/painting_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1  DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
CUDA_VISIBLE_DEVICES=0 python tools/train.py  --root ~/data --trainer ChannelAttenLossMSDAWithTarCompact \
	 --source-domains sketch infograph clipart quickdraw real --target-domains painting \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/painting  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_painting_batch8.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/quickdraw_model.pth.tar-40 OPTIM.MAX_EPOCH 20 TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 TRAINER.CALOSS.WEIGHT_CON 0.1 DATALOADER.TRAIN_X.BATCH_SIZE 80 DATALOADER.TRAIN_U.BATCH_SIZE 16'
CUDA_VISIBLE_DEVICES=4 python tools/train.py  --root ~/data --trainer ChannelAttenLossMSDAWithTarCompact \
	 --source-domains sketch infograph painting clipart real --target-domains quickdraw \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/quickdraw  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_quickdraw_batch8.log &
fi
