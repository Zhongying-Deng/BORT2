trainer=FixMatchTSVDDistNetMetaLearnRetrain
data_conf=configs/datasets/da/domainnet.yaml
conf=configs/trainers/da/domainnet_staged_lr.yaml
#opt='MODEL.BACKBONE.NAME resnet101_ms'
a=0
for((i=4;i<=4;i++));do
#if (( $a == 1 ));then
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS /home/dengzhongying/code/T-SVDNet-main/record/domainnet/infograph_best_model.pth OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/tsvd_meta_leran_retrain_domainnet/infograph/model4meta/model.pth.tar-15 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 15 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
CUDA_VISIBLE_DEVICES=0 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch painting clipart quickdraw real --target-domains infograph \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/tsvd_meta_leran_retrain_domainnet/infograph  \
   	 --resume output/mscm_retrain_domainnet/clipart/nomodel \
	 ${opt}  INPUT.PIXEL_MEAN '(0.5,0.5,0.5)' INPUT.PIXEL_STD '(0.5,0.5,0.5)' 2>&1| tee output/tsvd_meta_leran_retrain_domainnet/fm_infograph_${i}.log &
if (( $a == 1 ));then
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS /home/dengzhongying/code/T-SVDNet-main/record/domainnet/real_best_model.pth OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/tsvd_meta_leran_retrain_domainnet/real/model4meta/model.pth.tar-15 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 15 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
CUDA_VISIBLE_DEVICES=1 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart quickdraw painting --target-domains real \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/tsvd_meta_leran_retrain_domainnet/real  \
   	 --resume output/mscm_retrain_domainnet/clipart/nomodel \
	 ${opt}  INPUT.PIXEL_MEAN '(0.5,0.5,0.5)' INPUT.PIXEL_STD '(0.5,0.5,0.5)' 2>&1| tee output/tsvd_meta_leran_retrain_domainnet/fm_real_${i}.log &
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS /home/dengzhongying/code/T-SVDNet-main/record/domainnet/sketch_best_model.pth OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/tsvd_meta_leran_retrain_domainnet/sketch/model4meta/model.pth.tar-15 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 15 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
CUDA_VISIBLE_DEVICES=2 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains painting infograph clipart quickdraw real --target-domains sketch \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/tsvd_meta_leran_retrain_domainnet/sketch  \
   	 --resume output/mscm_retrain_domainnet/clipart/nomodel \
	 ${opt}  INPUT.PIXEL_MEAN '(0.5,0.5,0.5)' INPUT.PIXEL_STD '(0.5,0.5,0.5)' 2>&1| tee output/tsvd_meta_leran_retrain_domainnet/fm_sketch_${i}.log &
#else
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS /home/dengzhongying/code/T-SVDNet-main/record/domainnet/clipart_best_model.pth OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/tsvd_meta_leran_retrain_domainnet/clipart/model4meta/model.pth.tar-15 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 15 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
CUDA_VISIBLE_DEVICES=3 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph painting quickdraw real --target-domains clipart \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/tsvd_meta_leran_retrain_domainnet/clipart  \
   	 --resume output/mscm_retrain_domainnet/clipart/nomodel \
	 ${opt}  INPUT.PIXEL_MEAN '(0.5,0.5,0.5)' INPUT.PIXEL_STD '(0.5,0.5,0.5)' 2>&1| tee output/tsvd_meta_leran_retrain_domainnet/fm_clipart_${i}.log &
#else
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS /home/dengzhongying/code/T-SVDNet-main/record/domainnet/painting_best_model.pth OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/tsvd_meta_leran_retrain_domainnet/painting/model4meta/model.pth.tar-15 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 15 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
CUDA_VISIBLE_DEVICES=4 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart quickdraw real --target-domains painting \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/tsvd_meta_leran_retrain_domainnet/painting  \
   	 --resume output/mscm_retrain_domainnet/clipart/nomodel \
	 ${opt} INPUT.PIXEL_MEAN '(0.5,0.5,0.5)' INPUT.PIXEL_STD '(0.5,0.5,0.5)' 2>&1| tee output/tsvd_meta_leran_retrain_domainnet/fm_painting_${i}.log &
#fi
#opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS /home/dengzhongying/code/T-SVDNet-main/record/domainnet/quickdraw_best_model.pth OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 0 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/tsvd_meta_leran_retrain_domainnet/quickdraw/model4meta/model.pth.tar-15 OPTIM.MAX_EPOCH 15 MODEL.BACKBONE.NAME resnet101 TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 15 TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30 OPTIM.LR 0.002'
CUDA_VISIBLE_DEVICES=5 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart real painting --target-domains quickdraw \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/tsvd_meta_leran_retrain_domainnet/quickdraw  \
   	 --resume output/mscm_retrain_domainnet/clipart/nomodel \
	 ${opt} INPUT.PIXEL_MEAN '(0.5,0.5,0.5)' INPUT.PIXEL_STD '(0.5,0.5,0.5)' 2>&1| tee output/tsvd_meta_leran_retrain_domainnet/fm_quickdraw_${i}.log & 
fi
done
