#sleep 3h
trainer=ChannelAttenLossMSDA
data_conf=configs/datasets/da/domainnet_ca.yaml
conf=configs/trainers/da/ca_loss/domainnet_staged_lr.yaml
num=7
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/infograph_model.pth.tar-40 OPTIM.MAX_EPOCH 20  TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 MODEL.BACKBONE.NAME resnet101_ca_adapt_kernel TRAINER.FIXMATCH.EMA_ALPHA 0.999'
CUDA_VISIBLE_DEVICES=0 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch painting clipart quickdraw real --target-domains infograph \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/infograph  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_adaptkernel_infograph_${num}.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/real_model.pth.tar-40 OPTIM.MAX_EPOCH 20  TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 MODEL.BACKBONE.NAME resnet101_ca_adapt_kernel TRAINER.FIXMATCH.EMA_ALPHA 0.999'
CUDA_VISIBLE_DEVICES=1 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart quickdraw painting --target-domains real \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/real  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_adaptkernel_real_${num}.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/sketch_model.pth.tar-40 OPTIM.MAX_EPOCH 20  TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 MODEL.BACKBONE.NAME resnet101_ca_adapt_kernel TRAINER.FIXMATCH.EMA_ALPHA 0.999'
CUDA_VISIBLE_DEVICES=2 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains painting infograph clipart quickdraw real --target-domains sketch \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/sketch  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_adaptkernel_sketch_${num}.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/clipart_model.pth.tar-40 OPTIM.MAX_EPOCH 20  TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 MODEL.BACKBONE.NAME resnet101_ca_adapt_kernel TRAINER.FIXMATCH.EMA_ALPHA 0.999'
CUDA_VISIBLE_DEVICES=3 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph painting quickdraw real --target-domains clipart \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/clipart  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_adaptkernel_clipart_${num}.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/quickdraw_model.pth.tar-40 OPTIM.MAX_EPOCH 20  TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 MODEL.BACKBONE.NAME resnet101_ca_adapt_kernel TRAINER.FIXMATCH.EMA_ALPHA 0.999'
CUDA_VISIBLE_DEVICES=4 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph painting clipart real --target-domains quickdraw \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/quickdraw  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_adaptkernel_quickdraw_${num}.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/painting_model.pth.tar-40 OPTIM.MAX_EPOCH 20  TRAINER.CALOSS.WEIGHT_D .3 TRAINER.CALOSS.LOSS_TYPE L1 MODEL.BACKBONE.NAME resnet101_ca_adapt_kernel TRAINER.FIXMATCH.EMA_ALPHA 0.999'
CUDA_VISIBLE_DEVICES=5 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart quickdraw real --target-domains painting \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/caloss_domainnet/painting  \
   	 --resume output/caloss_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/caloss_domainnet/caloss_adaptkernel_painting_${num}.log &
