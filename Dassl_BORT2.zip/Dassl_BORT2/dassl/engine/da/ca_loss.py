import copy
import numpy as np
import torch
from torch.nn import functional as F
from torch.autograd import Function

from dassl.data import DataManager
from dassl.engine import TRAINER_REGISTRY, TrainerXU
from dassl.metrics import compute_accuracy
from dassl.data.transforms import build_transform
from dassl.engine.ssl import FixMatch
from dassl.evaluation import build_evaluator
from dassl.engine.trainer import SimpleNet
from dassl.utils import count_num_param
from dassl.optim import build_optimizer, build_lr_scheduler
from dassl.utils import load_pretrained_weights


def domain_discrepancy(out1, out2, loss_type='L2'):
    # TODO: use L2 distance instead of L1(abs)
    def huber_loss(e, d=1):
        t =torch.abs(e)
        ret = torch.where(t < d, 0.5 * t ** 2, d * (t - 0.5 * d))
        return torch.mean(ret)
    
    diff = torch.sum(out1.view(out1.size(0), -1), 0)/out1.size(0) - torch.sum(out2.view(out2.size(0), -1), 0)/out2.size(0)
    if loss_type == 'L1':
        loss = torch.mean(torch.abs(diff))
    elif loss_type == 'Huber':
        loss = huber_loss(diff)
    else:
        loss = torch.mean(diff*diff)
    return loss


def get_consistency_weight(consistency_scale, consistency_rampup, epoch):
    # Consistency ramp-up from https://arxiv.org/abs/1610.02242
    def sigmoid_rampup(current, rampup_length):
        """Exponential rampup from https://arxiv.org/abs/1610.02242"""
        import numpy as np
        if rampup_length == 0:
            return 1.0
        else:
            current = np.clip(current, 0.0, rampup_length)
            phase = 1.0 - current / rampup_length
            return float(np.exp(-5.0 * phase * phase))

    consistency_weight = consistency_scale * sigmoid_rampup(epoch, consistency_rampup)
    return consistency_weight


class Head(torch.nn.Module):
    def __init__(self, fdim, num_classes):
        super().__init__()
        self.classifier = torch.nn.Linear(fdim, num_classes)

    def forward(self, x):
        return self.classifier(x)


@TRAINER_REGISTRY.register()
class ChannelAttenLoss(FixMatch):
    """FixMatch: Simplifying Semi-Supervised Learning with
    Consistency and Confidence.

    https://arxiv.org/abs/2001.07685.

    FixMatch with channel attention(CBAM https://arxiv.org/abs/1807.06521) loss to reclibrate features
       and EMA(MeanTeacher https://arxiv.org/abs/1703.01780), 
       sharing config file with base FixMatch
    """

    def __init__(self, cfg):
        super().__init__(cfg)
        self.weight_u = cfg.TRAINER.FIXMATCH.WEIGHT_U
        self.conf_thre = cfg.TRAINER.FIXMATCH.CONF_THRE
        self.ema_alpha = cfg.TRAINER.FIXMATCH.EMA_ALPHA
        self.domain_loss_type = cfg.TRAINER.CALOSS.LOSS_TYPE
        self.ramp_up = cfg.TRAINER.CALOSS.RAMPUP
        self.weight_d = cfg.TRAINER.CALOSS.WEIGHT_D  # channel attention domain loss weight
        self.weight_con = cfg.TRAINER.CALOSS.WEIGHT_CON  # consisitency loss weight
        # evaluator for EMA model 
        self.evaluator_teacher = build_evaluator(cfg, lab2cname=self.dm.lab2cname)
        self.acc = []
        self.acc_teacher = []
        self.num_samples = 0
        self.total_num = 0

    def build_model(self):
        cfg = self.cfg
        print('Building model')
        assert 'ca' in cfg.MODEL.BACKBONE.NAME, 'Wrong backbone name {}. ' \
           'There must be ca (channel attention) in the backbone, e.g. resnet18_ca'.format(cfg.Model.BACKBONE.NAME)
        self.model = SimpleNet(cfg, cfg.MODEL, 0)
        if cfg.MODEL.INIT_WEIGHTS:
            load_pretrained_weights(self.model, cfg.MODEL.INIT_WEIGHTS)
        self.model.to(self.device)
        print('# params: {:,}'.format(count_num_param(self.model)))
        self.optim = build_optimizer(self.model, cfg.OPTIM)
        self.sched = build_lr_scheduler(self.optim, cfg.OPTIM)
        self.register_model('model', self.model, self.optim, self.sched)
        
        fdim = self.model.fdim
        #self.classifier = Head(fdim, self.num_classes)
        self.classifier = torch.nn.Linear(fdim, self.num_classes)
        if cfg.MODEL.INIT_HEAD_WEIGHTS:
            load_pretrained_weights(self.classifier, cfg.MODEL.INIT_HEAD_WEIGHTS)
        else:
            try:
                load_pretrained_weights(self.classifier, cfg.MODEL.INIT_WEIGHTS)
            except:
                print('No wights found for classifier at {}'.format(cfg.MODEL.INIT_WEIGHTS))
        self.classifier.to(self.device)
        self.optim_c = build_optimizer(self.classifier, cfg.OPTIM, head_momentum=True)
        self.sched_c = build_lr_scheduler(self.optim_c, cfg.OPTIM)
        self.register_model('classifier', self.classifier, self.optim_c, self.sched_c)

        # build EMA model
        self.teacher = copy.deepcopy(self.model)
        self.teacher.train()
        for param in self.teacher.parameters():
            param.requires_grad_(False)

        self.teacher_classifier = copy.deepcopy(self.classifier)
        self.teacher_classifier.train()
        for param in self.teacher_classifier.parameters():
            param.requires_grad_(False)
        self.lr_sched_type = cfg.OPTIM.LR_SCHEDULER
    
    def forward_backward(self, batch_x, batch_u):
        global_step = self.batch_idx + self.epoch * self.num_batches
        #global_step = self.epoch + self.batch_idx / self.num_batches
        parsed_data = self.parse_batch_train(batch_x, batch_u)
        input_x, input_x2, label_x, input_u, input_u2 = parsed_data
        input_u = torch.cat([input_x, input_u], 0)
        input_u2 = torch.cat([input_x2, input_u2], 0)

        # Generate artificial label
        feat_weak, tar_ca_weak = self.model(input_u)
        with torch.no_grad():
            #feat_weak, tar_ca_weak = self.model(input_u)
            output_u = F.softmax(self.classifier(feat_weak), 1)
            max_prob, label_u = output_u.max(1)
            mask_u = (max_prob >= self.conf_thre).float()
            feat_teacher, _ = self.teacher(input_u)
            output_u_teacher = F.softmax(self.teacher_classifier(feat_teacher), 1)
            max_prob_t, label_u_t = output_u_teacher.max(1)
            mask_u_t = (max_prob_t >= self.conf_thre).float()
            # pseudo label of EMA and student model should be consistent
            label_consist = (label_u == label_u_t).float()
            # accept the pseudo label with a probility
            avg_prob = (max_prob_t + max_prob)/2.
            probility = torch.tensor(np.random.rand(max_prob_t.size(0)))
            random_mask = (avg_prob > probility.float().to(self.device)).float()

            mask_u = mask_u * mask_u_t * label_consist * random_mask
            self.num_samples += mask_u.sum()
            self.total_num += label_u.size()[0]


        # Supervised loss
        feat_x, src_ca = self.model(input_x)
        output_x = self.classifier(feat_x)
        loss_x = F.cross_entropy(output_x, label_x)

        # Unsupervised loss
        feat_u, tar_ca_strong = self.model(input_u2)
        output_u = self.classifier(feat_u)
        loss_u = F.cross_entropy(output_u, label_u, reduction='none')
        loss_u = (loss_u * mask_u).mean()

        loss = loss_x + loss_u * self.weight_u
        loss_summary = {
            'loss_x': loss_x.item(),
            'acc_x': compute_accuracy(output_x, label_x)[0].item(),
            'loss_u': loss_u.item(),
            'acc_u': compute_accuracy(output_u, label_u)[0].item()
        }

        # Channel attention loss for feature reclibration
        src_ca_last1, src_ca_last2 = torch.split(src_ca[-1], 16, 0)
        #src_ca_seclast1, src_ca_seclast2, src_ca_seclast3, src_ca_seclast4 = torch.split(src_ca[-2], 64, 0)
        if self.weight_d > 0:
            #tar_ca = tar_ca_strong
            #loss_d_last_layer = domain_discrepancy(src_ca[-1], tar_ca[-1], self.domain_loss_type)+domain_discrepancy(src_ca[-1], tar_ca_weak[-1], self.domain_loss_type)
            #loss_domain_ca = self.weight_d * (loss_d_last_layer + \
            #        domain_discrepancy(src_ca[-2], tar_ca[-2], self.domain_loss_type)+domain_discrepancy(src_ca[-2], tar_ca_weak[-2], self.domain_loss_type)) #+ \
            #        #domain_discrepancy(src_ca[-3], tar_ca[-3], self.domain_loss_type))
            #loss_domain_ca = self.weight_d * loss_d_last_layer 
            avg_prob = avg_prob.unsqueeze(1).repeat(1, 256).unsqueeze(2).unsqueeze(3)
            tar_ca = torch.cat([avg_prob*tar_ca_strong[-1], tar_ca_weak[-1]], 0)
            loss_d_last_layer = 0 * domain_discrepancy(src_ca[-1], tar_ca, self.domain_loss_type) + \
                    domain_discrepancy(src_ca_last1, tar_ca, self.domain_loss_type) + \
                    domain_discrepancy(src_ca_last2, tar_ca, self.domain_loss_type) #+ \
                    #domain_discrepancy(src_ca_last3, tar_ca, self.domain_loss_type) + domain_discrepancy(src_ca_last4, tar_ca, self.domain_loss_type)
            loss_domain_ca = self.weight_d * (loss_d_last_layer) #+ \
                    #domain_discrepancy(src_ca[-2], torch.cat([tar_ca_strong[-2], tar_ca_weak[-2]], 0), self.domain_loss_type)) # + domain_discrepancy(src_ca[-3], torch.cat([tar_ca_strong[-3], tar_ca_weak[-3]], 0), self.domain_loss_type))#+domain_discrepancy(src_ca_seclast1, src_ca_seclast2, self.domain_loss_type)+domain_discrepancy(src_ca_seclast2, src_ca_seclast3, self.domain_loss_type)+domain_discrepancy(src_ca_seclast3, src_ca_seclast4, self.domain_loss_type)+domain_discrepancy(src_ca_seclast4, src_ca_seclast1, self.domain_loss_type))
            loss += loss_domain_ca
            loss_summary['loss_d'] = loss_domain_ca.item()
            loss_summary['loss_d_last'] = self.weight_d * loss_d_last_layer.item()
        if self.weight_con > 0:
            with torch.no_grad():
                feat_teacher_weak, ca_weak_teacher = self.teacher(input_u)
                #feat_teacher_str, ca_str_teacher = self.teacher(input_u2)
                consistency_weight = get_consistency_weight(self.weight_con, self.ramp_up, self.epoch)
            consistency_loss = consistency_weight * (F.mse_loss(tar_ca_strong[-1], ca_weak_teacher[-1]) + F.mse_loss(tar_ca_strong[-2], ca_weak_teacher[-2]))
            loss += consistency_loss
            loss_summary['loss_con'] = consistency_loss.item()

        self.model_backward_and_update(loss)
      
        # update EMA model
        ema_alpha = min(1 - 1 / (global_step+1), self.ema_alpha)
        self.ema_model_update(self.model, self.teacher, ema_alpha)
        self.ema_model_update(self.classifier, self.teacher_classifier, ema_alpha)

        if self.lr_sched_type != 'fixmatch':
            if (self.batch_idx + 1) == self.num_batches:
                self.update_lr()
        else:
            self.update_lr()

        return loss_summary

    def ema_model_update(self, model, ema, decay):
        ema_has_module = hasattr(ema, 'module')
        needs_module = hasattr(model, 'module') and not ema_has_module
        #decay = min(1 - 1 / (step + 1), decay)
        with torch.no_grad():
            msd = model.state_dict()
            for k, ema_v in ema.state_dict().items():
                if needs_module:
                    k = 'module.' + k
                model_v = msd[k].detach()
                ema_v.copy_(ema_v * decay + (1. - decay) * model_v)
                # weight decay
                # if 'bn' not in k:
                #     msd[k] = msd[k] * (1. - self.wd)

    @torch.no_grad()
    def test(self):
        """A generic testing pipeline."""
        # display samples above the threshold
        print('samples above the threshold {}({}/{})'.format(
            float(self.num_samples ) / self.total_num, self.num_samples, self.total_num))
        self.num_samples = 0
        self.total_num = 0

        self.set_model_mode('eval')
        self.teacher.eval()
        self.teacher_classifier.eval()
        self.evaluator.reset()
        self.evaluator_teacher.reset()
        
        split = self.cfg.TEST.SPLIT
        print('Do evaluation on {} set'.format(split))
        data_loader = self.val_loader if split == 'val' else self.test_loader
        assert data_loader is not None
        
        for batch_idx, batch in enumerate(data_loader):
            input, label = self.parse_batch_test(batch)
            output, _ = self.model_inference(input)
            output = self.classifier(output)
            self.evaluator.process(output, label)
            output_teacher, _ = self.teacher(input)
            output_teacher = self.teacher_classifier(output_teacher)
            self.evaluator_teacher.process(output_teacher, label)
            
        results = self.evaluator.evaluate()
        results_teacher = self.evaluator_teacher.evaluate()
            
        for k, v in results.items():
            tag = '{}/{}'.format(split, k)
            self.write_scalar(tag, v, self.epoch)
        self.acc.append(results['accuracy'])

        for k, v in results_teacher.items():
            tag_ema = 'ema_{}/{}'.format(split, k)
            self.write_scalar(tag_ema, v, self.epoch)
        self.teacher.train()
        self.teacher_classifier.train()
        self.acc_teacher.append(results_teacher['accuracy'])
        print('Until epoch {}, best accuracy of student model {}, teacher model {}'.format(self.epoch, max(self.acc), max(self.acc_teacher)))


