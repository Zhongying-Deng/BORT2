import copy
import torch
import torch.nn as nn
from torch.nn import functional as F
from torch.autograd import Function

from dassl.data import DataManager
from dassl.engine import TRAINER_REGISTRY, TrainerXU
from dassl.metrics import compute_accuracy
from dassl.data.transforms import build_transform
from dassl.engine.ssl import FixMatch
from dassl.evaluation import build_evaluator

from dassl.utils import count_num_param
from dassl.optim import build_optimizer, build_lr_scheduler
from dassl.modeling import build_head, build_backbone
from dassl.utils import load_pretrained_weights

class SimpleNet(nn.Module):
    """A simple neural network composed of a CNN backbone
    and optionally a head such as mlp for classification.
    """

    def __init__(self, cfg, model_cfg, num_classes, **kwargs):
        super().__init__()
        self.backbone = build_backbone(
            model_cfg.BACKBONE.NAME,
            verbose=cfg.VERBOSE,
            pretrained=model_cfg.BACKBONE.PRETRAINED,
            **kwargs
        )
        self._fdim = self.backbone.out_features

    @property
    def fdim(self):
        return self._fdim

    def forward(self, x):
        f, atten = self.backbone(x)
        return f, atten


class Head(nn.Module):
    """Head for VisDA dataset.
       stack of several Dropout-FC-BN-ReLU layers
    """

    def __init__(self, cfg, model_cfg, num_classes, fdim, **kwargs):
        super().__init__()
        self.head = None
        if model_cfg.HEAD.NAME and model_cfg.HEAD.HIDDEN_LAYERS:
            self.head = build_head(
                model_cfg.HEAD.NAME,
                verbose=cfg.VERBOSE,
                in_features=fdim,
                hidden_layers=model_cfg.HEAD.HIDDEN_LAYERS,
                activation=model_cfg.HEAD.ACTIVATION,
                bn=model_cfg.HEAD.BN,
                dropout=model_cfg.HEAD.DROPOUT,
                **kwargs
            )
            fdim = self.head.out_features

        self.classifier = None
        if num_classes > 0:
            self.classifier = nn.Linear(fdim, num_classes)

        self._fdim = fdim

    @property
    def fdim(self):
        return self._fdim

    def forward(self, f):
        if self.head is not None:
            f = self.head(f)

        if self.classifier is None:
            return f

        y = self.classifier(f)
        return y


class DomainAdaptiveCenterLoss(nn.Module):
    """
    Domain Adaptive Center loss, adapted from https://github.com/jxgu1016/MNIST_center_loss_pytorch
    """
    def __init__(self, num_classes, feat_dim, size_average=True):
        super(DomainAdaptiveCenterLoss, self).__init__()
        self.centers = nn.Parameter(torch.randn(num_classes, feat_dim))
        self.centerlossfunc = CenterlossFunc.apply
        self.feat_dim = feat_dim
        self.size_average = size_average

    def forward(self, feat_src, label_src, feat_tar, label_tar, weights=None):
        if weights is None:
            weights = torch.ones(feat_tar.size(0))
        feat_src = feat_src.view(feat_src.size(0), -1)
        feat_tar = feat_tar.view(feat_tar.size(0), -1)
        # To check the dim of centers and features
        if feat_src.size(1) != self.feat_dim:
            raise ValueError("Center's dim: {0} should be equal to input feature's \
                            dim: {1}".format(self.feat_dim, feat_src.size(1)))

        loss = self.centerlossfunc(feat_src, label_src, self.centers, feat_tar, label_tar, weights)
        return loss


class CenterlossFunc(Function):
    @staticmethod
    def forward(ctx, feat_src, label_src, centers, feat_tar, label_tar, weights):
        # ctx is used to save parameters, similar to self.save_for_backward()

        centers_batch = centers.index_select(0, label_tar.long())
        batch_size_tar = feat_tar.size(0)
        diff_square = (feat_tar - centers_batch).pow(2)
        assert diff_square.size(0) == weights.size(0), 'The batch size of features should equal to the length of weights'
        weights = weights.unsqueeze(1).expand(diff_square.size(0), diff_square.size(1))
        if diff_square.is_cuda:
            weights = weights.cuda()
        loss = torch.sum(diff_square * weights) / 2.0 / batch_size_tar
        ctx.save_for_backward(feat_src, label_src, centers, feat_tar, label_tar, weights)
        return loss.squeeze()

    @staticmethod
    def backward(ctx, grad_output):
        feat_src, label_src, centers, feat_tar, label_tar, weights = ctx.saved_tensors
        # gradient w.r.t centers. Note that centers are updated with features of source domain
        batch_size_src = feat_src.size(0)
        centers_batch = centers.index_select(0, label_src.long())

        diff_src = centers_batch - feat_src
        # init every iteration
        counts = centers.new_ones(centers.size(0))
        ones = centers.new_ones(label_src.size(0))
        grad_centers = centers.new_zeros(centers.size())

        counts = counts.scatter_add_(0, label_src.long(), ones)
        grad_centers.scatter_add_(0, label_src.unsqueeze(1).expand(feat_src.size()).long(), diff_src)
        grad_centers = grad_centers/counts.view(-1, 1)

        # gradient w.r.t features of target domain
        centers_batch_tar = centers.index_select(0, label_tar.long())
        diff = weights * (centers_batch_tar - feat_tar)
        batch_size_tar = feat_tar.size(0)
        # return the gradient w.r.t the inputs, each element returned by backward function corresponding to each input in forward pass
        return None, None, grad_centers / batch_size_src, - grad_output * diff / batch_size_tar, None, None


def get_consistency_weight(consistency_scale, consistency_rampup, epoch):
    # Consistency ramp-up from https://arxiv.org/abs/1610.02242
    def sigmoid_rampup(current, rampup_length):
        """Exponential rampup from https://arxiv.org/abs/1610.02242"""
        import numpy as np
        if rampup_length == 0:
            return 1.0
        else:
            current = np.clip(current, 0.0, rampup_length)
            phase = 1.0 - current / rampup_length
            return float(np.exp(-5.0 * phase * phase))

    consistency_weight = consistency_scale * sigmoid_rampup(epoch, consistency_rampup)
    return consistency_weight


@TRAINER_REGISTRY.register()
class ChannelAttenDACLVisDA(FixMatch):
    """FixMatch: Simplifying Semi-Supervised Learning with
    Consistency and Confidence.

    https://arxiv.org/abs/2001.07685.

    FixMatch with channel attention(CBAM https://arxiv.org/abs/1807.06521) loss to reclibrate features
       and EMA(MeanTeacher https://arxiv.org/abs/1703.01780), 
       sharing config file with base FixMatch
    """

    def __init__(self, cfg):
        super().__init__(cfg)
        self.weight_u = cfg.TRAINER.FIXMATCH.WEIGHT_U
        self.conf_thre = cfg.TRAINER.FIXMATCH.CONF_THRE
        self.ema_alpha = cfg.TRAINER.FIXMATCH.EMA_ALPHA
        self.domain_loss_type = cfg.TRAINER.CALOSS.LOSS_TYPE
        self.ramp_up = cfg.TRAINER.CALOSS.RAMPUP
        self.weight_d = cfg.TRAINER.CALOSS.WEIGHT_D
        self.weight_con = cfg.TRAINER.CALOSS.WEIGHT_CON  # consisitency loss weight
        # evaluator for EMA model 
        self.evaluator_teacher = build_evaluator(cfg, lab2cname=self.dm.lab2cname)
        self.acc = []
        self.acc_teacher = []
        self.num_samples = 0
        self.total_num = 0

    def build_model(self):
        cfg = self.cfg
        print('Building model')
        assert 'ca' in cfg.MODEL.BACKBONE.NAME, 'Wrong backbone name {}. ' \
           'There must be ca (channel attention) in the backbone, e.g. resnet18_ca'.format(cfg.Model.BACKBONE.NAME)
        self.model = SimpleNet(cfg, cfg.MODEL, 0)
        if cfg.MODEL.INIT_WEIGHTS:
            load_pretrained_weights(self.model, cfg.MODEL.INIT_WEIGHTS)
        self.model.to(self.device)
        fdim = self.model.fdim
        self.model = torch.nn.DataParallel(self.model)
        print('# params: {:,}'.format(count_num_param(self.model)))
        self.optim = build_optimizer(self.model, cfg.OPTIM)
        self.sched = build_lr_scheduler(self.optim, cfg.OPTIM)
        self.register_model('model', self.model, self.optim, self.sched)
        
        #fdim = self.model.fdim
        #self.classifier = torch.nn.Linear(fdim, self.num_classes)
        self.classifier = Head(cfg, cfg.MODEL, self.num_classes, fdim)
        if cfg.MODEL.INIT_HEAD_WEIGHTS:
            load_pretrained_weights(self.classifier, cfg.MODEL.INIT_HEAD_WEIGHTS)
        else:
            load_pretrained_weights(self.classifier, cfg.MODEL.INIT_WEIGHTS)

        self.classifier.to(self.device)
        self.classifier = torch.nn.DataParallel(self.classifier)
        #self.optim_c = build_optimizer(self.classifier, cfg.OPTIM)
        self.optim_c = build_optimizer(self.classifier, cfg.OPTIM, head_momentum=True)
        self.sched_c = build_lr_scheduler(self.optim_c, cfg.OPTIM)
        self.register_model('classifier', self.classifier, self.optim_c, self.sched_c)

        # build EMA model
        self.teacher = copy.deepcopy(self.model)
        self.teacher.train()
        for param in self.teacher.parameters():
            param.requires_grad_(False)

        self.teacher_classifier = copy.deepcopy(self.classifier)
        self.teacher_classifier.train()
        for param in self.teacher_classifier.parameters():
            param.requires_grad_(False)
        
        # initialize Domain Adaptive Center Loss
        if 'cnn_digit5' in cfg.MODEL.BACKBONE.NAME:
            self.domain_loss_last = DomainAdaptiveCenterLoss(self.num_classes, 128)
            self.domain_loss_sec_last = DomainAdaptiveCenterLoss(self.num_classes, 64)
            #self.domain_loss_third_last = DomainAdaptiveCenterLoss(self.num_classes, 64)
        elif 'resnet18' in cfg.MODEL.BACKBONE.NAME or 'resnet34' in cfg.MODEL.BACKBONE.NAME:
            self.domain_loss_last = DomainAdaptiveCenterLoss(self.num_classes, 512)
            self.domain_loss_sec_last = DomainAdaptiveCenterLoss(self.num_classes, 256)
            #self.domain_loss_third_last = DomainAdaptiveCenterLoss(self.num_classes, 128)
        else:
            self.domain_loss_last = DomainAdaptiveCenterLoss(self.num_classes, 2048)
            self.domain_loss_sec_last = DomainAdaptiveCenterLoss(self.num_classes, 1024)
            #self.domain_loss_third_last = DomainAdaptiveCenterLoss(self.num_classes, 512)
        self.domain_loss_last.to(self.device)
        self.domain_loss_sec_last.to(self.device)
        #self.domain_loss_third_last.to(self.device)
        self.domain_loss_last = torch.nn.DataParallel(self.domain_loss_last)
        self.domain_loss_sec_last = torch.nn.DataParallel(self.domain_loss_sec_last)
        self.optim_dacl_last = build_optimizer(self.domain_loss_last, cfg.OPTIM, head_momentum=True)
        self.optim_dacl_sec_last = build_optimizer(self.domain_loss_sec_last, cfg.OPTIM, head_momentum=True)
        #self.optim_dacl = build_optimizer([
        #    {'params': self.domain_loss_last.parameters()},
        #    {'params': self.domain_loss_sec_last.parameters()},
        #    {'params': self.domain_loss_third_last.parameters()}], cfg.OPTIM)
        self.sched_dacl_last = build_lr_scheduler(self.optim_dacl_last, cfg.OPTIM)
        self.sched_dacl_sec_last = build_lr_scheduler(self.optim_dacl_sec_last, cfg.OPTIM)
        self.register_model('dacl_last', self.domain_loss_last, self.optim_dacl_last, self.sched_dacl_last)
        self.register_model('dacl_sec_last', self.domain_loss_sec_last, self.optim_dacl_sec_last, self.sched_dacl_sec_last)
        self.lr_sched_type = cfg.OPTIM.LR_SCHEDULER

    def forward_backward(self, batch_x, batch_u):
        global_step = self.batch_idx + self.epoch * self.num_batches
        #global_step = self.epoch + self.batch_idx / self.num_batches
        parsed_data = self.parse_batch_train(batch_x, batch_u)
        input_x, input_x2, label_x, input_u, input_u2 = parsed_data
        input_u = torch.cat([input_x, input_u], 0)
        input_u2 = torch.cat([input_x2, input_u2], 0)

        # Generate artificial label
        feat_weak, tar_ca_weak = self.model(input_u)
        with torch.no_grad():
            #feat_weak, tar_ca_weak = self.model(input_u)
            output_u = F.softmax(self.classifier(feat_weak), 1)
            max_prob, label_u = output_u.max(1)
            mask_u = (max_prob >= self.conf_thre).float()
            self.num_samples += mask_u.sum()
            self.total_num += label_u.size()[0]

        # Supervised loss
        feat_x, src_ca = self.model(input_x)
        output_x = self.classifier(feat_x)
        loss_x = F.cross_entropy(output_x, label_x)

        # Unsupervised loss
        feat_u, tar_ca_strong = self.model(input_u2)
        output_u = self.classifier(feat_u)
        loss_u = F.cross_entropy(output_u, label_u, reduction='none')
        loss_u = (loss_u * mask_u).mean()

        loss = loss_x + loss_u * self.weight_u
        loss_summary = {
            'loss_x': loss_x.item(),
            'acc_x': compute_accuracy(output_x, label_x)[0].item(),
            'loss_u': loss_u.item(),
            'acc_u': compute_accuracy(output_u, label_u)[0].item()
        }
        if self.weight_d > 0:
            tar_ca = tar_ca_weak
            weights = max_prob.float() # mask/max_probs.float() for hard/soft version of weights
            loss_d_last_layer = self.domain_loss_last(src_ca[-1], label_x, tar_ca[-1], label_u, weights)
            rampup_weight = get_consistency_weight(self.weight_d, self.ramp_up, self.epoch)
            loss_domain_ca = rampup_weight * (loss_d_last_layer + \
                    self.domain_loss_sec_last(src_ca[-2], label_x, tar_ca[-2], label_u, weights))
            loss += loss_domain_ca
            loss_summary['loss_d'] = loss_domain_ca.item()
            loss_summary['loss_d_last'] = rampup_weight * loss_d_last_layer.item()
        if self.weight_con > 0:
            with torch.no_grad():
                feat_teacher_weak, ca_weak_teacher = self.teacher(input_u)
                #feat_teacher_str, ca_str_teacher = self.teacher(input_u2)
                consistency_weight = get_consistency_weight(self.weight_con, self.ramp_up, self.epoch)
            consistency_loss = consistency_weight * (F.mse_loss(tar_ca_strong[-1], ca_weak_teacher[-1]) + F.mse_loss(tar_ca_strong[-2], ca_weak_teacher[-2]))
            loss += consistency_loss
            loss_summary['loss_con'] = consistency_loss.item()

        self.model_backward_and_update(loss)
      
        # update EMA model
        ema_alpha = min(1 - 1 / (global_step+1), self.ema_alpha)
        self.ema_model_update(self.model, self.teacher, ema_alpha)
        self.ema_model_update(self.classifier, self.teacher_classifier, ema_alpha)

        if self.lr_sched_type != 'fixmatch':
            if (self.batch_idx + 1) == self.num_batches:
                self.update_lr()
        else:
            self.update_lr()

        return loss_summary

    def ema_model_update(self, model, ema, decay):
        ema_has_module = hasattr(ema, 'module')
        needs_module = hasattr(model, 'module') and not ema_has_module
        #decay = min(1 - 1 / (step + 1), decay)
        with torch.no_grad():
            msd = model.state_dict()
            for k, ema_v in ema.state_dict().items():
                if needs_module:
                    k = 'module.' + k
                model_v = msd[k].detach()
                ema_v.copy_(ema_v * decay + (1. - decay) * model_v)
                # weight decay
                # if 'bn' not in k:
                #     msd[k] = msd[k] * (1. - self.wd)

    @torch.no_grad()
    def test(self):
        """A generic testing pipeline."""
        # display samples above the threshold
        print('samples above the threshold {}({}/{})'.format(
            float(self.num_samples ) / self.total_num, self.num_samples, self.total_num))
        self.num_samples = 0
        self.total_num = 0

        self.set_model_mode('eval')
        self.teacher.eval()
        self.teacher_classifier.eval()
        self.evaluator.reset()
        self.evaluator_teacher.reset()
        
        split = self.cfg.TEST.SPLIT
        print('Do evaluation on {} set'.format(split))
        data_loader = self.val_loader if split == 'val' else self.test_loader
        assert data_loader is not None
        
        for batch_idx, batch in enumerate(data_loader):
            input, label = self.parse_batch_test(batch)
            output, _ = self.model_inference(input)
            output = self.classifier(output)
            self.evaluator.process(output, label)
            output_teacher, _ = self.teacher(input)
            output_teacher = self.teacher_classifier(output_teacher)
            self.evaluator_teacher.process(output_teacher, label)
            
        results = self.evaluator.evaluate()
        results_teacher = self.evaluator_teacher.evaluate()
            
        for k, v in results.items():
            tag = '{}/{}'.format(split, k)
            self.write_scalar(tag, v, self.epoch)
        self.acc.append(results['accuracy'])

        for k, v in results_teacher.items():
            tag_ema = 'ema_{}/{}'.format(split, k)
            self.write_scalar(tag_ema, v, self.epoch)
        self.teacher.train()
        self.teacher_classifier.train()
        self.acc_teacher.append(results_teacher['accuracy'])
        print('Until epoch {}, best accuracy of student model {}, teacher model {}'.format(self.epoch, max(self.acc), max(self.acc_teacher)))

