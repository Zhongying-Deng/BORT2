import copy
from random import uniform
import numpy as np
import torch
from torch.nn import functional as F
import torchvision.transforms as T

from dassl.data import DataManager
from dassl.engine import TRAINER_REGISTRY, TrainerXU
from dassl.metrics import compute_accuracy
from dassl.data.transforms import build_transform
from dassl.engine.ssl import FixMatch
from dassl.evaluation import build_evaluator
from dassl.engine.trainer import SimpleNet
from dassl.utils import count_num_param, cutmix, mix_amplitude
from dassl.optim import build_optimizer, build_lr_scheduler
from dassl.modeling import build_head, build_backbone
from dassl.modeling.ops.utils import create_onehot


class DomainBasedNet(SimpleNet):
    """A simple neural network composed of a CNN backbone
    and optionally a head such as mlp for classification.
    """
    def __init__(self, cfg, model_cfg, num_classes, **kwargs):
        super().__init__(cfg, model_cfg, num_classes)
        self.backbone = build_backbone(
                model_cfg.BACKBONE.NAME,
                verbose=cfg.VERBOSE,
                pretrained=model_cfg.BACKBONE.PRETRAINED,
                #style_g_train=style_g_train,
                **kwargs
                )
        fdim = self.backbone.out_features
        if 'ms' in model_cfg.BACKBONE.NAME:
            self.use_mixstyle = True
        else:
            self.use_mixstyle = False
        if 'st' in model_cfg.BACKBONE.NAME:
            self.use_styletrans = True
        else:
            self.use_styletrans = False
        self.head = None
        if model_cfg.HEAD.NAME and model_cfg.HEAD.HIDDEN_LAYERS:
            self.head = build_head(
                model_cfg.HEAD.NAME,
                verbose=cfg.VERBOSE,
                in_features=fdim,
                hidden_layers=model_cfg.HEAD.HIDDEN_LAYERS,
                activation=model_cfg.HEAD.ACTIVATION,
                bn=model_cfg.HEAD.BN,
                dropout=model_cfg.HEAD.DROPOUT,
            )
            fdim = self.head.out_features


    def forward(self, x, return_feature=False, domain_btcsize=None,
                use_mixstyle=False, use_st=False, lmda=None, prob=None):
        if self.use_mixstyle:
            f = self.backbone(x, domain_btcsize=domain_btcsize,
                    use_mixstyle=use_mixstyle, lmda=lmda, prob=prob)
        elif self.use_styletrans:
            f = self.backbone(x, domain_btcsize=domain_btcsize,
                    use_st=use_st, lmda=lmda)
        else:
            f = self.backbone(x)
        if isinstance(f, tuple):
            f, loss = f
            with_loss = True
        else:
            with_loss = False
        if self.head is not None:
            f = self.head(f)

        if self.classifier is None:
            if with_loss and self.use_styletrans:
                return f, loss
            else:
                return f

        y = self.classifier(f)

        if return_feature:
            if with_loss and self.use_styletrans:
                return y, f, loss
            else:
                return y, f
        if with_loss and self.use_styletrans:
            return y, loss
        else:
            return y


@TRAINER_REGISTRY.register()
class FixMatchMSCMDataSampling(FixMatch):
    """FixMatch: Simplifying Semi-Supervised Learning with
    Consistency and Confidence.

    https://arxiv.org/abs/2001.07685.

    FixMatch with Domain labels, sharing config file with base FixMatch,
    also with CutMix and MixStyle

    Sangdoo Yun et al. 'CutMix: Regularization Strategy to Train Strong Classifiers with Localizable Features'. ICCV 2019
    Kaiyang Zhou, Yongxin Yang, Yu Qiao, and Tao Xiang. Domain Generalization with MixStyle. ICLR, 2021
    """
    def __init__(self, cfg):
        super().__init__(cfg)
        self.weight_u = cfg.TRAINER.FIXMATCH.WEIGHT_U
        self.conf_thre = cfg.TRAINER.FIXMATCH.CONF_THRE
        self.ema_alpha = cfg.TRAINER.FIXMATCH.EMA_ALPHA
        self.weight_st = cfg.TRAINER.STYLETRANS.WEIGHT

        self.teacher = copy.deepcopy(self.model)
        self.teacher.train()
        for param in self.teacher.parameters():
            param.requires_grad_(False)
        self.evaluator_teacher = build_evaluator(cfg, lab2cname=self.dm.lab2cname)
        self.acc = []
        self.acc_teacher = []
        self.num_samples = 0
        self.total_num = 0
        self.lr_sched_type = cfg.OPTIM.LR_SCHEDULER
        self.x_btch_size = cfg.DATALOADER.TRAIN_X.BATCH_SIZE
        self.u_btch_size = cfg.DATALOADER.TRAIN_U.BATCH_SIZE
        #self.n_domain = cfg.DATALOADER.TRAIN_X.N_DOMAIN # this one is zero
        self.n_domain = len(self.cfg.DATASET.SOURCE_DOMAINS)
        batch_size = cfg.DATALOADER.TRAIN_X.BATCH_SIZE
        self.split_batch = batch_size // self.n_domain
        #self.lmda = torch.tensor(1.)
        self.cutmix_prob = cfg.TRAINER.CUTMIX.PROB
        self.cutmix_beta = cfg.TRAINER.CUTMIX.BETA
        self.warmup = 1
        self.threshold_u = torch.tensor([1. for _ in range(self.num_classes)]).to(self.device)
        self.temperature = 5.

    def build_model(self):
        cfg = self.cfg
        print('Building model')
        ms_cfg = cfg.TRAINER.MIXSTYLE.CONFIG
        self.model = DomainBasedNet(cfg, cfg.MODEL, self.num_classes, ms_cfg=ms_cfg, style_g_train=True)
        if cfg.MODEL.INIT_WEIGHTS:
            load_pretrained_weights(self.model, cfg.MODEL.INIT_WEIGHTS)
        self.model.to(self.device)
        print('# params: {:,}'.format(count_num_param(self.model)))
        self.optim = build_optimizer(self.model, cfg.OPTIM)
        self.sched = build_lr_scheduler(self.optim, cfg.OPTIM)
        self.register_model('model', self.model, self.optim, self.sched)
        if 'st' in cfg.MODEL.BACKBONE.NAME:
            self.use_styletrans = True
        else:
            self.use_styletrans = False


    def forward_backward(self, batch_x, batch_u):
        global_step = self.batch_idx + self.epoch * self.num_batches
        #lmda = torch.tensor(1 - float(global_step) / (self.max_epoch * self.num_batches))
        #lmda = torch.tensor(0.)
        #lmda = torch.tensor(1 - float(global_step) / (10 * self.num_batches))
        #lmda = F.relu(lmda)
        #prob = 0.5 + min(float(global_step) / (10 * self.num_batches), 0.5)
        prob = 1.
        lmda = None
        #global_step = self.epoch + self.batch_idx / self.num_batches
        parsed_data = self.parse_batch_train(batch_x, batch_u)
        input_x, input_x2, label_x, input_u, input_u2 = parsed_data
        x_bs = input_x.size(0)
        #band_width = uniform(0.01, 0.09)
        #input_x = FDA_source_to_target(input_x, input_u, L=band_width)
        #input_x2_fda = mix_amplitude(input_x2, input_u2)
        #if input_u2.is_cuda:
        #    #input_x = input_x.cuda()
        #    input_x2_fda = input_x2_fda.cuda()
        input_u1 = torch.cat([input_x, input_u], 0)
        #input_u2 = torch.cat([input_x2, input_u2], 0)
        domain_btch_size = [self.split_batch for _ in range(self.n_domain)]

        #if self.epoch > 5:
        #    use_mixstyle = True
        #else:
        use_mixstyle = False
        # Generate artificial label
        with torch.no_grad():
            #output_u = F.softmax(self.teacher(input_u), 1)
            # when generating pseudo labels, we do not use MixStyle
            domain_btch_size.append(input_u.size(0))
            output_u = F.softmax(self.model(input_u1, use_mixstyle=use_mixstyle, use_st=False,
                                            domain_btcsize=domain_btch_size, lmda=lmda), 1)
            #output_u = F.softmax(self.model(input_u1), 1)
            del domain_btch_size[-1]
            max_prob, label_u = output_u.max(1)
            mask_u = (max_prob >= self.conf_thre).float()
            self.num_samples += mask_u[x_bs:].sum()
            self.total_num += label_u[x_bs:].size()[0]
            pred_label_x = label_u[0:x_bs]
            pred_mask_x = mask_u[0:x_bs]
            # index for samples that has wrong prediction
            idx = torch.nonzero(pred_label_x != label_x)
            idx = idx.squeeze()
            #import pdb
            #pdb.set_trace()
            mask_loss_x = (~pred_mask_x.bool()) + (pred_label_x != label_x)
            idx_loss_x = torch.nonzero(mask_loss_x).squeeze()
            output_tmp = output_u[x_bs:, :]
            entropy = - torch.mean(output_tmp * torch.log(output_tmp + 1e-6), dim=1, keepdim=True)
            avg_ent = self.ent(torch.mean(output_tmp, dim=0))
            lmda = torch.tanh(entropy/avg_ent).view(entropy.size(0), 1, 1, 1)
            #lmda = torch.clamp(entropy/avg_ent, 0., 1.).view(entropy.size(0), 1, 1, 1)
            #print('average entropy of mini-batch {:.4f}, '
            #        ' max and min value of lmda {:.4f}, {:.4f}'.format(
            #            avg_ent.item(), torch.max(lmda).item(), torch.min(lmda).item()))

            if False:#self.epoch < self.warmup:
                #prob_x = output_u[0:x_bs, :]
                #mask_x = create_onehot(label_x, self.num_classes).to(self.device)
                #num_class_x = torch.sum(mask_x, 0)
                #num_class_x = torch.max(num_class_x, torch.ones_like(num_class_x)) #avoid divide by zero
                #avg_prob = torch.sum(prob_x * mask_x, dim=0) / num_class_x
                #self.threshold_u = self.ema_alpha * self.threshold_u + (1. - self.ema_alpha) * avg_prob
                prob_x = max_prob[0:x_bs]
                threshold = prob_x.mean() - 3 * prob_x.std()
                self.threshold_u = self.ema_alpha * self.threshold_u + (1. - self.ema_alpha) * threshold
                #print('threshold (max {}, min {}), temperature {}, ent {}, soft mask (min {}, max {})'.format(self.threshold_u.max(), self.threshold_u.min(), self.temperature, entropy/avg_ent, soft_mask.min(), soft_mask.max()))
        #print(idx, idx.size())
        idx = idx_loss_x
        if self.epoch > self.warmup:
            #with torch.no_grad():
            #    output_tmp = output_u[x_bs:, :]
            #    #entropy = self.ent(output_tmp)
            #    entropy = torch.mean(- torch.sum(output_tmp * torch.log(output_tmp + 1e-6), dim=1))
            #    avg_ent = self.ent(torch.mean(output_tmp, dim=0))
            #    self.temperature = self.ema_alpha * self.temperature + \
            #            (1. - self.ema_alpha) * (entropy/avg_ent)
            #    #self.temperature = F.relu(self.temperature - 1.) + 1. # temperature larger than 1.
            #    soft_mask = (max_prob[x_bs:] - self.threshold_u[label_u[x_bs:]]) * self.temperature
            #    soft_mask = torch.sigmoid(soft_mask)
                
            #    prob_u = max_prob[x_bs:]
            #    threshold = prob_u.mean() - prob_u.std()
            #    self.threshold_u = self.ema_alpha * self.threshold_u + (1. - self.ema_alpha) * threshold
            #    soft_mask = (prob_u >= self.threshold_u[0]).float()

            if idx.numel() > 0:
                input_x2 = torch.index_select(input_x2, 0, idx)
                input_u2 = torch.cat([input_x2, input_u2], 0)
                label_x2 = torch.index_select(label_x, 0, idx)
                # use groundtruth label of input_x for cutmix
                label_u = torch.cat([label_x2, label_u[x_bs:]])
                # since we use groundtruth label of input_x, mask for input_x is all ones
                mask_x = torch.index_select(pred_mask_x, 0, idx)
                mask_x = torch.ones_like(mask_x).float()
                mask_u = torch.cat([mask_x, mask_u[x_bs:]], 0)
                #mask_u = torch.cat([mask_x, soft_mask], 0)
            else:
                label_u = label_u[x_bs:]
                mask_u = mask_u[x_bs:]
                #mask_u = soft_mask
        else:
            input_u2 = torch.cat([input_x2, input_u2], 0)
        #print('input_x2 size {}'.format(input_x2.size()))
        #label_x_pseudo = torch.index_select(pred_label_x, 0, idx)
        #label_u = torch.cat([label_x_pseudo, label_u[x_bs:]])
        with torch.no_grad():
            r = np.random.rand(1)
            if r < self.cutmix_prob:
                input_u2, label_u_mix, label_mix_weight, mask_u_mix = cutmix(
                         input_u2, label_u, self.cutmix_beta, mask_u)
            else:
                label_u_mix, mask_u_mix = label_u, mask_u
                label_mix_weight = 1.
        if self.epoch > self.warmup: #idx.numel() > 0
            input_x = torch.index_select(input_x, 0, idx_loss_x)
            label_x = torch.index_select(label_x, 0, idx_loss_x)
            #pass
        #else:
        #    mask_loss_x = torch.ones_like(pred_mask_x).float()
        if self.epoch < self.warmup or idx_loss_x.numel() > 1:
            output_x = self.model(input_x, use_mixstyle=False)#, use_st=False)
            loss_x = F.cross_entropy(output_x, label_x)
            #loss_x = F.cross_entropy(output_x, label_x, reduction='none')
            #loss_x = (mask_loss_x * loss_x).mean()
        else:
            loss_x = torch.tensor(0.).to(self.device)

        # Unsupervised loss
        if idx.numel() > 0:
            use_mixstyle = True
            #domain_btch_size.append(input_u2.size(0) - input_x2.size(0))
            domain_btch_size = [input_x2.size(0), input_u2.size(0) - input_x2.size(0)]
        else:
            use_mixstyle = False
            domain_btch_size = None
        if self.use_styletrans and domain_btch_size is not None:
            output_u, loss_st = self.model(input_u2, use_mixstyle=use_mixstyle, use_st=True,
                    domain_btcsize=domain_btch_size, lmda=lmda)
        else:
            output_u = self.model(input_u2, use_mixstyle=use_mixstyle, use_st=False,
                    domain_btcsize=domain_btch_size, lmda=lmda, prob=prob)
            loss_st = [torch.tensor(0.).to(self.device)]
        #del domain_btch_size[-1]
        loss_u = F.cross_entropy(output_u, label_u, reduction='none')
        loss_u = label_mix_weight * (loss_u * mask_u).mean()
        loss_u_mix = F.cross_entropy(output_u, label_u_mix, reduction='none')
        loss_u_mix = (1. - label_mix_weight) * (loss_u_mix * mask_u_mix).mean()

        loss = loss_x + (loss_u + loss_u_mix) * self.weight_u
        if self.use_styletrans:
            num = 0
            loss_st_all = 0
            for i in loss_st:
                num += 1
                loss_st_all += i
            loss_st_all = loss_st_all * self.weight_st / num
            loss += loss_st_all

        self.model_backward_and_update(loss)

        ema_alpha = min(1 - 1 / (global_step+1), self.ema_alpha)
        self.ema_model_update(self.model, self.teacher, ema_alpha)

        loss_summary = {
            'loss_x': loss_x.item(),
            #'acc_x': compute_accuracy(output_x, label_x)[0].item(),
            'loss_u': loss_u.item(),
            'acc_u': compute_accuracy(output_u, label_u)[0].item(),
            'num_x': input_x.size(0),
            #'num_x2': input_x2.size(0)
        }
        if self.epoch > self.warmup:
           loss_summary['threshold_max'] = self.threshold_u.max().item()
           #loss_summary['threshold_min'] = self.threshold_u.min().item()
           loss_summary['avg_ent'] = avg_ent.max().item()
           loss_summary['lmda_max'] = lmda.max().item()
           loss_summary['lmda_min'] = lmda.min().item()
           #loss_summary['threshold_avg_prob'] = avg_prob.mean().item()
           #loss_summary['threshold'] = threshold.item()
           #if torch.is_tensor(self.temperature):
           #    loss_summary['temp'] = self.temperature.item()
           #else:
           #    loss_summary['temp'] = self.temperature
           #loss_summary['soft_mask_max'] = soft_mask.max().item()
           #loss_summary['soft_mask_min'] = soft_mask.min().item()

        if self.use_styletrans:
            loss_summary['loss_st'] = loss_st_all.item()

        if self.lr_sched_type != 'fixmatch':
            if (self.batch_idx + 1) == self.num_batches:
                self.update_lr()
        else:
            self.update_lr()

        return loss_summary

    def ema_model_update(self, model, ema, decay):
        ema_has_module = hasattr(ema, 'module')
        needs_module = hasattr(model, 'module') and not ema_has_module
        #decay = min(1 - 1 / (step + 1), decay)
        with torch.no_grad():
            msd = model.state_dict()
            for k, ema_v in ema.state_dict().items():
                if needs_module:
                    k = 'module.' + k
                model_v = msd[k].detach()
                ema_v.copy_(ema_v * decay + (1. - decay) * model_v)
                # weight decay
                # if 'bn' not in k:
                #     msd[k] = msd[k] * (1. - self.wd)

    def ent(self, output):
        return - torch.mean(output * torch.log(output + 1e-6))

    @torch.no_grad()
    def test(self):
        """A generic testing pipeline."""
        # display samples above the threshold
        print('samples above the threshold {}({}/{})'.format(
            float(self.num_samples ) / self.total_num, self.num_samples, self.total_num))
        #self.lmda = torch.tensor(float(self.num_samples ) / self.total_num)
        self.num_samples = 0
        self.total_num = 0

        self.set_model_mode('eval')
        self.teacher.eval()
        self.evaluator.reset()
        self.evaluator_teacher.reset()

        split = self.cfg.TEST.SPLIT
        print('Do evaluation on {} set'.format(split))
        data_loader = self.val_loader if split == 'val' else self.test_loader
        assert data_loader is not None

        for batch_idx, batch in enumerate(data_loader):
            input, label = self.parse_batch_test(batch)
            output = self.model_inference(input)
            self.evaluator.process(output, label)
            output_teacher = self.teacher(input)
            self.evaluator_teacher.process(output_teacher, label)

        results = self.evaluator.evaluate()
        results_teacher = self.evaluator_teacher.evaluate()

        for k, v in results.items():
            tag = '{}/{}'.format(split, k)
            self.write_scalar(tag, v, self.epoch)
        self.acc.append(results['accuracy'])

        for k, v in results_teacher.items():
            tag_ema = 'ema_{}/{}'.format(split, k)
            self.write_scalar(tag_ema, v, self.epoch)
        self.teacher.train()
        self.acc_teacher.append(results_teacher['accuracy'])
        print('Until epoch {}, best accuracy of student model {}, teacher model {}'.format(self.epoch, max(self.acc), max(self.acc_teacher)))




