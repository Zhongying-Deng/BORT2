from .build import build_head, HEAD_REGISTRY # isort:skip

from .mlp import mlp
from .visda_head import visda_head

