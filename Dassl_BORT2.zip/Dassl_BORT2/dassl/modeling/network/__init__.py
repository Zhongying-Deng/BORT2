from .build import build_network, NETWORK_REGISTRY # isort:skip

from .ddaig_fcn import (
    fcn_3x32_gctx, fcn_3x64_gctx, fcn_3x32_gctx_stn, fcn_3x64_gctx_stn
)
