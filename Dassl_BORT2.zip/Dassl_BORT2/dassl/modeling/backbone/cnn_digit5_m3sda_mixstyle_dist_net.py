"""
Reference

https://github.com/VisionLearningGroup/VisionLearningGroup.github.io/tree/master/M3SDA
"""
import torch.nn as nn
from torch.nn import functional as F

from .build import BACKBONE_REGISTRY
from .backbone import Backbone
from .mixstyle import MixStyle


class FeatureExtractor(Backbone):

    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 64, kernel_size=5, stride=1, padding=2)
        self.bn1 = nn.BatchNorm2d(64)
        self.ms1 = MixStyle(64)
        self.conv2 = nn.Conv2d(64, 64, kernel_size=5, stride=1, padding=2)
        self.bn2 = nn.BatchNorm2d(64)
        #self.ms2 = MixStyleFromGenerator(64)
        #self.ms2_style_g = StyleGenerator(64)
        self.conv3 = nn.Conv2d(64, 128, kernel_size=5, stride=1, padding=2)
        self.bn3 = nn.BatchNorm2d(128)
        self.fc1 = nn.Linear(8192, 3072)
        self.bn1_fc = nn.BatchNorm1d(3072)
        self.fc2 = nn.Linear(3072, 2048)
        self.bn2_fc = nn.BatchNorm1d(2048)
        self.dist_net_conv = nn.Linear(3072, 2048)
        self.dist_net_bn = nn.BatchNorm1d(2048)
        self.single_src = False
        self._out_features = 2048

    def _check_input(self, x):
        H, W = x.shape[2:]
        assert H == 32 and W == 32, \
            'Input to network must be 32x32, ' \
            'but got {}x{}'.format(H, W)

    def forward(self, x, domain_btcsize=None, use_mixstyle=True, lmda=None):
        self._check_input(x)
        x = self.conv1(x)
        if not self.single_src:
            x = self.bn1(x)
        x = F.relu(x)
        if use_mixstyle:
            x = self.ms1(x, use_mix_style=use_mixstyle, lmda=lmda)
        #x =F.relu(x)
        #else:
        #    x = self.bn1(x)
        #x = F.relu(x)
        x = F.max_pool2d(x, stride=2, kernel_size=3, padding=1)
        x = self.conv2(x)
        #if not self.single_src:
        x = self.bn2(x)
        x = F.relu(x)
        #if use_mixstyle:
        #    x = self.ms1(x, use_mix_style=use_mixstyle, lmda=lmda)

        x = F.max_pool2d(x, stride=2, kernel_size=3, padding=1)
        x = F.relu(self.bn3(self.conv3(x)))
        x = x.view(x.size(0), 8192)
        x = F.relu(self.bn1_fc(self.fc1(x)))
        x = F.dropout(x, training=self.training)
        sig = F.relu(self.dist_net_bn(self.dist_net_conv(x)))
        sig = F.dropout(sig, training=self.training)
        x = F.relu(self.bn2_fc(self.fc2(x)))
        return x, sig


@BACKBONE_REGISTRY.register()
def cnn_digit5_m3sda_ms_dist_net(**kwargs):
    """
    This architecture was used for the Digit-5 dataset in:

        - Peng et al. Moment Matching for Multi-Source
        Domain Adaptation. ICCV 2019.
    """
    return FeatureExtractor()
