from .svhn import SVHN
from .cifar import CIFAR10, CIFAR100
from .stl10 import STL10
