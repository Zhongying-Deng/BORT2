trainer=FixMatchLabelMix
data_conf=configs/datasets/da/domainnet.yaml
conf=configs/trainers/da/domainnet_staged_lr.yaml
#opt='MODEL.BACKBONE.NAME resnet101_adapkernel'
a=0
for((i=8;i<=8;i++));do
if (( $a == 1 ));then
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/real_model.pth.tar-40 OPTIM.MAX_EPOCH 20 MODEL.BACKBONE.NAME resnet101_adapkernel'
CUDA_VISIBLE_DEVICES=1 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart quickdraw painting --target-domains real \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/adaptkernel_domainnet/real  \
   	 --resume output/adaptkernel_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/adaptkernel_domainnet/fm_real_${i}.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/sketch_model.pth.tar-40 OPTIM.MAX_EPOCH 20 MODEL.BACKBONE.NAME resnet101_adapkernel'
CUDA_VISIBLE_DEVICES=2 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains painting infograph clipart quickdraw real --target-domains sketch \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/adaptkernel_domainnet/sketch  \
   	 --resume output/adaptkernel_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/adaptkernel_domainnet/fm_sketch_${i}.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/clipart_model.pth.tar-40 OPTIM.MAX_EPOCH 20 MODEL.BACKBONE.NAME resnet101_adapkernel'
CUDA_VISIBLE_DEVICES=3 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph painting quickdraw real --target-domains clipart \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/adaptkernel_domainnet/clipart  \
   	 --resume output/adaptkernel_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/adaptkernel_domainnet/fm_clipart_${i}.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/painting_model.pth.tar-40 OPTIM.MAX_EPOCH 20 MODEL.BACKBONE.NAME resnet101_adapkernel'
CUDA_VISIBLE_DEVICES=4 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart quickdraw real --target-domains painting \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/adaptkernel_domainnet/painting  \
   	 --resume output/adaptkernel_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/adaptkernel_domainnet/fm_painting_${i}.log &
else
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/quickdraw_model.pth.tar-40 OPTIM.MAX_EPOCH 20 MODEL.BACKBONE.NAME resnet101_adapkernel'
CUDA_VISIBLE_DEVICES=0 python tools/train.py  --root ~/data --trainer ${trainer} \
	 --source-domains sketch infograph clipart real painting --target-domains quickdraw \
  	 --dataset-config-file ${data_conf}   --config-file ${conf}    \
      	 --output-dir output/adaptkernel_domainnet/quickdraw  \
   	 --resume output/adaptkernel_domainnet/clipart/nomodel \
	 ${opt} 2>&1| tee output/adaptkernel_domainnet/fm_quickdraw_${i}.log &
opt='MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/fixmatch_domainnet/infograph_model.pth.tar-40 OPTIM.MAX_EPOCH 20 MODEL.BACKBONE.NAME resnet101_adapkernel'
CUDA_VISIBLE_DEVICES=1 python tools/train.py  --root ~/data --trainer ${trainer} \
         --source-domains sketch painting clipart quickdraw real --target-domains infograph \
         --dataset-config-file ${data_conf}   --config-file ${conf}    \
         --output-dir output/adaptkernel_domainnet/infograph  \
         --resume output/adaptkernel_domainnet/clipart/nomodel \
         ${opt} 2>&1| tee output/adaptkernel_domainnet/fm_infograph_${i}.log &

fi
done
