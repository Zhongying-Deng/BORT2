metatrain=1
if (( $metatrain == 1 )); then
trainer=FixMatchBaselinesDistNetMetaLearnRetrain
else
trainer=FixMatchBaselinesDistNetRetrain
fi
conf=configs/trainers/da/pacs_staged_lr.yaml
#conf=configs/trainers/da/source_only/pacs_staged_lr.yaml
data_conf=configs/datasets/da/pacs.yaml
#opt='MODEL.BACKBONE.NAME resnet18 OPTIM.MAX_EPOCH 20'
for((i=8;i<=8;i++));do
if (( $metatrain == 0 )); then
        GPU=4
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/photo_drt/F/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18_drt' 
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon sketch --target-domains photo  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/photo_drt --resume output/src_only_pacs/sketch/nomodel $opt  2>&1|tee output/pacs_baselines_retrain/drt_photo_${i}.log &
	GPU=5
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/sketch_drt/F/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18_drt'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon photo --target-domains sketch  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/sketch_drt --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/drt_sketch_${i}.log &
	#sleep 7m
	GPU=6
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/cartoon_drt/F/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18_drt'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting sketch photo --target-domains cartoon  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/cartoon_drt --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/drt_cartoon_${i}.log &
	GPU=7
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines/art_drt/F/model.pth.tar-20 MODEL.BACKBONE.NAME resnet18_drt'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains sketch cartoon photo --target-domains art_painting  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/art_drt --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/drt_art_${i}.log &
else
        GPU=0
   	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines_retrain/photo_drt/model/model.pth.tar-50 MODEL.BACKBONE.NAME resnet18_drt TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30' 
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon sketch --target-domains photo  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/photo_drt_meta --resume output/src_only_pacs/sketch/nomodel $opt  2>&1|tee output/pacs_baselines_retrain/drt_photo_${i}.log &
	GPU=1
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines_retrain/sketch_drt/model/model.pth.tar-50 MODEL.BACKBONE.NAME resnet18_drt TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting cartoon photo --target-domains sketch  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/sketch_drt_meta --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/drt_sketch_${i}.log &
	#sleep 7m
	GPU=2
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines_retrain/cartoon_drt/model/model.pth.tar-50 MODEL.BACKBONE.NAME resnet18_drt TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains art_painting sketch photo --target-domains cartoon  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/cartoon_drt_meta --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/drt_cartoon_${i}.log &
	GPU=3
	opt='TRAINER.RETRAIN.RATIO 0.95 OPTIM.MAX_EPOCH 50 TRAINER.RETRAIN.EPOCH 50 MODEL.BACKBONE.PRETRAINED False MODEL.INIT_WEIGHTS output/pacs_baselines_retrain/art_drt/model/model.pth.tar-50 MODEL.BACKBONE.NAME resnet18_drt TRAINER.METALEARN.TYPE sgd TRAINER.METALEARN.LR 0.00005 TRAINER.METALEARN.STEP 30'
	CUDA_VISIBLE_DEVICES=${GPU} python tools/train.py --root ../../data/ --trainer $trainer --source-domains sketch cartoon photo --target-domains art_painting  --dataset-config-file $data_conf --config-file $conf  --output-dir output/pacs_baselines_retrain/art_drt_meta --resume output/src_only_pacs/sketch/nomodel $opt 2>&1|tee output/pacs_baselines_retrain/drt_art_${i}.log & 
fi
done
