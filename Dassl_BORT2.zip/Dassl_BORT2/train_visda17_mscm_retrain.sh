conf=configs/trainers/da/visda17.yaml
data_conf=configs/datasets/da/visda17_mcd_setting.yaml 
trainer=FixMatchMSCMRetrain
a=0
for((i=0;i<=0;i++));do
GPU=3
opt='MODEL.BACKBONE.NAME resnet101_ms TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 1. TRAINER.RETRAIN.EPOCH 10 OPTIM.MAX_EPOCH 20'
CUDA_VISIBLE_DEVICES=$GPU python tools/train.py --root ../../data --trainer $trainer \
	--source-domains synthetic --target-domains real  \
	--dataset-config-file ${data_conf} --config-file ${conf}  \
        --output-dir output/mscm_retrain_visda --resume output/adaptkernel_digit5/usps/nomodel  \
	$opt 2>&1|tee output/mscm_retrain_visda/fm_mscm_retrain_real_${i}.log &
if (( $a == 1 ));then
((GPU=GPU+1))
opt='MODEL.BACKBONE.NAME resnet101_ms TRAINER.RETRAIN.RATIO 0.95 TRAINER.CUTMIX.PROB 0. TRAINER.RETRAIN.EPOCH 10 OPTIM.MAX_EPOCH 20'
CUDA_VISIBLE_DEVICES=$GPU python tools/train.py --root ../../data --trainer $trainer \
	--source-domains mnist mnist_m svhn usps --target-domains syn  \
	--dataset-config-file ${data_conf} --config-file ${conf}  \
	--output-dir output/mscm_retrain_digit5/syn --resume output/adaptkernel_digit5/usps/nomodel  \
	$opt 2>&1|tee output/mscm_retrain_digit5/fm_mscm_retrain_syn_1.log &
fi
done
